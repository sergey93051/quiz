<?php

function maxNum($arg)
{
    $tmp = $arg[0];
    for ($i = 0; $i < count($arg); $i++) {

        if ($arg[$i] > $tmp) {
            $tmp = $arg[$i];
        }
    }
    return $tmp;
}


print(maxNum([5, 50, 3, 70, 150, 61]));
