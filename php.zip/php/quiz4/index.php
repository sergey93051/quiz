<?php
$res = "";
$index = 0;
$s = "*";
for ($i = 1; $i < 5; $i++) {
    $res .= $s;
    if ($i == 4) {
        $res .= $s . "<br>";
        $i = 0;
        $index++;
        if ($index == 4) {
            break;
        }
    }
}
echo $res;
