<?php

function PrNumbool($num)
{

    if ($num % 2 === 0) {
        return "true";
    } else {
        return "false";
    }
}
echo PrNumbool(20);
