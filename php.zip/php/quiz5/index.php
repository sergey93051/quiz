<?php

$s  = "";
for ($i = 0; $i < 8; $i++) {
    for ($m = 0; $m <= $i; $m++) {
        $s .= "*";
    }
    $s .= "<br>";
}
echo $s;
