<?php

function  Prnum($num)
{
    $res = '';
    for ($i = $num; $i >= 0; $i--) {
        if ($i % 2 !== 0) {
            $res .= $i;
            break;
        }
    }

    return $res;
}

echo Prnum(20);
