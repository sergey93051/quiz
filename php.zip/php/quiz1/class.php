<?php
class Myproj
{
    private $text;

    public  function __construct($t)
    {
        $this->text = $t;
    }
    public function validation()
    {
        $re = '~^[A-Za-z0-9]{0,6}$~';
        return preg_match($re, $this->text);
    }
    public function project()
    {
        $mytext = $this->text;

        $result = [];
        for ($i = 0; $i < strlen($mytext); $i++) {
            $res = $mytext[0];
            for ($j = 0; $j < strlen($mytext) - 1; $j++) {
                $tmp =  $mytext[$j + 1];
                $mytext[$j + 1] = $mytext[$j];
                $mytext[$j] = $tmp;
                $res .=  $mytext[$j];
            }
            $result[] = $res;
        }

        return $result;
    }
}
