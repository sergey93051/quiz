<?php
include "class.php";
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>quiz1</title>
</head>

<body>
    <div>
        <form action="index.php" method="Post">
            <input type="text" name="myText">
            <input type="submit" name="sendText" value="send">
        </form>
    </div>
    <div>
        <?php
        if (isset($_POST['sendText'])) :
            $myproj = new Myproj($_POST['myText']);
            if ($myproj->validation() == true) :
                foreach ($myproj->project() as  $v) {
                    echo " <table>";
                    echo "<tr>";
                    echo  "<td>" . $v . "</td>";
                    echo  " </tr>";
                    echo  " </table>";
                }
            else :
                echo "must not exceed 6 charsd";
            endif;
        endif;
        ?>
    </div>
</body>

</html>